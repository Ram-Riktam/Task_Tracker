<script>
    import Board from "../Components/Board.svelte";


</script>
<Board/>
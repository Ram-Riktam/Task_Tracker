# create_table.py - Run this first
from app.database import init_db

if __name__ == "__main__":
    print("Creating database table...")
    init_db()
    print("Table created successfully!")
    
    # Test connection
    from app.database import engine
    from sqlalchemy import text
    
    with engine.connect() as conn:
        result = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))
        tables = result.fetchall()
        print(f"Tables found: {[table[0] for table in tables]}")
        
        # Check card table structure
        if any('card' in str(table) for table in tables):
            result = conn.execute(text("PRAGMA table_info(card)"))
            columns = result.fetchall()
            print("Card table columns:")
            for col in columns:
                print(f"  - {col[1]} ({col[2]})")
        else:
            print("Card table not found!")
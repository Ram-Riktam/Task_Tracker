from aiohttp import web

@web.middleware
async def error_middleware(request, handler):
    try:
        response = await handler(request)
        return response
    except web.HTTPException as ex:
        return web.json_response({"error": ex.reason}, status=ex.status)
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)

def setup_middlewares(app):
    app.middlewares.append(error_middleware)

import sqlalchemy as sa
import sqlalchemy.dialects.postgresql as pg
import uuid
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()

class Card(Base):
    __tablename__ = "cards"

    id = sa.Column(pg.UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    task_number = sa.Column(sa.String, unique=True)
    title = sa.Column(sa.String, nullable=False)
    description = sa.Column(sa.String)
    status = sa.Column(sa.String, default="todo")
    added_by = sa.Column(sa.String, default="frontend")
    created_at = sa.Column(sa.DateTime, default=datetime.utcnow)
    updated_at = sa.Column(sa.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

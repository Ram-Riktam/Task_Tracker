from aiohttp import web
from sqlalchemy.future import select
from datetime import datetime
from app.database import AsyncSessionLocal
from app.models import Card

# GET all cards
async def list_cards(request):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Card))
        cards = result.scalars().all()
        return web.json_response([c.as_dict() for c in cards])

# CREATE card
async def create_card(request):
    data = await request.json()
    async with AsyncSessionLocal() as session:
        # Auto increment task_number
        result = await session.execute(select(Card).order_by(Card.created_at.desc()))
        last_card = result.scalars().first()
        if last_card and last_card.task_number.startswith("TASK-"):
            last_num = int(last_card.task_number.split("-")[1])
            new_task_number = f"TASK-{last_num+1:03d}"
        else:
            new_task_number = "TASK-001"

        card = Card(
            task_number=new_task_number,
            title=data.get("title"),
            description=data.get("description"),
            status=data.get("status", "todo"),
            added_by=data.get("added_by", "frontend"),
        )
        session.add(card)
        await session.commit()
        await session.refresh(card)
        return web.json_response(card.as_dict(), status=201)

# UPDATE card
async def update_card(request):
    card_id = request.match_info["id"]
    data = await request.json()
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Card).where(Card.id == card_id))
        card = result.scalars().first()
        if not card:
            return web.json_response({"error": "Card not found"}, status=404)

        card.title = data.get("title", card.title)
        card.description = data.get("description", card.description)
        card.status = data.get("status", card.status)
        card.added_by = data.get("added_by", card.added_by)
        card.updated_at = datetime.utcnow()

        await session.commit()
        await session.refresh(card)
        return web.json_response(card.as_dict())

# DELETE card
async def delete_card(request):
    card_id = request.match_info["id"]
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Card).where(Card.id == card_id))
        card = result.scalars().first()
        if not card:
            return web.json_response({"error": "Card not found"}, status=404)

        await session.delete(card)
        await session.commit()
        return web.json_response({"message": "Card deleted"})
